//
//  Globals.swift
//  TestApplication
//
//  Created by Diksha on 22/08/23.
//

import Foundation

let initialBackendURL: String = "https://reqres.in/api/users"
var backendURL: String = initialBackendURL
